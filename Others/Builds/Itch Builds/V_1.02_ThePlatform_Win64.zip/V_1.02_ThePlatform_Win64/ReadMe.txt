CONTROLS:

- WASD/Arrows 		=> Walk
- Walk + LShift	        => Sprint
- Space 		=> Jump 
- 1-9 			=> Select inventory bar slot
- E			=> Collect resources, interact with buildings 
- Escape 		=> Open menu
- TAB			=> Open/close inventory/crafting menu
- H                     => Hide/Show UI
	
- Use grappler: 
       Hold left mouse button to charge and then release to start the ray (you don't need to fully charged; the ray length depends on the charge amount).
       Try to aim the ray to the falling resources. You can collect multiple resources at once!

- Use Plasma Blaster
       Hold left mouse button until FULLY charged and then release to shoot a bullet (as an indicator, when the charge is full, the crosshair changes its color).
       Try to aim the asteroids! Bullets that come close to an asteroid will make it explode. Be aware that these bullets take some time until they reach the asteroids,
       and the asteroids are travelling at high speed.

- When holding food/full water cup:
       Click left mouse button -> Eat/Drink




!VERY IMPORTANT: The game does not have a save system YET, so all the progress you make will be lost when leaving the game, or going to the main menu.
                 We are sorry for this, and we are trying to bring a working save system to the game as fast as possible.



CREDITS:

- Ui click sound effect from Zapsplat.com
- Eat sound effect from Zapsplat.com