CONTROLS:

- WASD/Arrows 		=> Walk
- Walk + LShift	        => Sprint
- Space 		=> Jump 
- 1-9 			=> Select inventory bar slot
- E			=> Collect resources, interact with buildings 
- Escape 		=> Open menu
- TAB			=> Open/close inventory/crafting menu
- H                     => Hide/Show UI
	
- Use grappler: 
       Hold left mouse button until fully charged (or less) and then release to start the ray. Try to aim the ray to the falling resources. You can collect
       multiple resources at once!

- When holding food/full water cup:
       Click left mouse button -> Eat/Drink




!VERY IMPORTANT: The game does not have a save system YET, so all the progress you make will be lost when leaving the game, or going to the main menu.
                 We are sorry for this, and we are trying to bring a working save system to the game as fast as possible.



CREDITS:

- Ui click sound effect from Zapsplat.com
- Eat sound effect from Zapsplat.com